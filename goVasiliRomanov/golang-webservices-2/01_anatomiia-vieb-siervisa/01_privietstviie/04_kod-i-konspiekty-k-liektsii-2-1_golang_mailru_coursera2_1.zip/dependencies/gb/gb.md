https://github.com/constabulary/gb

gb build

gb vendor fetch google.golang.org/grpc

gb vendor list
gb vendor fetch
gb vendor update
gb vendor restore